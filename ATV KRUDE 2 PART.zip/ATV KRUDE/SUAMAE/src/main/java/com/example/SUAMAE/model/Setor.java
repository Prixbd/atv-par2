package com.example.SUAMAE.model;

public enum Setor {
    ENGENHARIA,
    SAUDE,
    JURIDICO
}
