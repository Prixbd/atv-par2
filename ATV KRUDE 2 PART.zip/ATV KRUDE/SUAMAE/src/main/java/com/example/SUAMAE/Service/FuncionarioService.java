package com.example.SUAMAE.Service;

import com.example.SUAMAE.model.Funcionario;
import com.example.SUAMAE.repository.FuncionaRepository;
import jakarta.validation.Valid;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

import java.util.List;

@Service
@Validated
public class FuncionarioService {
    private FuncionaRepository funcionaRepository;

    public FuncionarioService (FuncionaRepository funcionaRepository){

        this.funcionaRepository = funcionaRepository;
    }

    public List<Funcionario> listarFuncionario(){
        return funcionaRepository.findAll();
    }

    public Funcionario salvar (@Valid Funcionario funcionario){

        if (funcionaRepository.findByEmail(funcionario.getEmail()).isPresent())
            throw  new RuntimeException("E-mail já cadastrado");
        return funcionaRepository.save(funcionario);
    }

    public Funcionario atualizar(@Valid Funcionario funcionario){
        Funcionario funcionarioAtualizar = funcionaRepository.findById(funcionario.getId())
                .orElseThrow(() -> new RuntimeException("Funcionario não Encontrado."));

        funcionarioAtualizar.setNome(funcionario.getNome());
        funcionarioAtualizar.setEmail(funcionario.getEmail());
        funcionarioAtualizar.setId(funcionario.getId());
        funcionarioAtualizar.setCpf(funcionario.getCpf());
        funcionarioAtualizar.setRg(funcionario.getRg());
        funcionarioAtualizar.setEndereco(funcionario.getEndereco());
        funcionarioAtualizar.setDataNascimento(funcionario.getDataNascimento());
        funcionarioAtualizar.setMatricula(funcionario.getMatricula());
        funcionarioAtualizar.setSalario(funcionario.getSalario());
        funcionarioAtualizar.setTelefone(funcionario.getTelefone());
        funcionarioAtualizar.setSetor(funcionario.getSetor());
        funcionarioAtualizar.setSexo(funcionario.getSexo());

        return funcionaRepository.save(funcionarioAtualizar);
   }

   public void excluir(String email){
        Funcionario funcionario = funcionaRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Funcionario não Encontrado."));
        funcionaRepository.deleteById(funcionario.getId());
   }
}
